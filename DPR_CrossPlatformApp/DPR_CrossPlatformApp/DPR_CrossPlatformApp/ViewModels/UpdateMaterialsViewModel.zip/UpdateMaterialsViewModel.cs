﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace DPR_CrossPlatformApp.ViewModels
{
    public class UpdateMaterialsViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private string strAPIUrl = "https://juniortogenius.com";

        private ObservableCollection<Project> _projects;

        public ObservableCollection<Project> Projects
        {
            get { return _projects; }
            set
            {
                if (_projects != value)
                {
                    _projects = value;
                    OnPropertyChanged(nameof(Projects));
                }
            }
        }

        private ObservableCollection<Block> _blocks;
        public ObservableCollection<Block> Blocks
        {
            get { return _blocks; }
            set
            {
                if (_blocks != value)
                {
                    _blocks = value;
                    OnPropertyChanged(nameof(Blocks));
                }
            }
        }

        private ObservableCollection<Component> _components;
        public ObservableCollection<Component> Components
        {
            get { return _components; }
            set
            {
                if (_components != value)
                {
                    _components = value;
                    OnPropertyChanged(nameof(Components));
                }
            }
        }




        public UpdateMaterialsViewModel()
        {
            // Initialize properties or perform any setup logic
        }

        public async Task LoadData()
        {
            Projects = await GetProjectsFromWebApi();
        }
        private string _selectedBoqReference;
        public string SelectedBoqReference
        {
            get => _selectedBoqReference;
            set
            {
                if (_selectedBoqReference != value)
                {
                    _selectedBoqReference = value;

                    // Update other properties based on the selected BOQ Reference
                    UpdateLabelsBasedOnBoqReference(value);

                    OnPropertyChanged(nameof(SelectedBoqReference));
                }
            }
        }
        private string _typeOfPipe;
        public string TypeOfPipe
        {
            get => _typeOfPipe;
            set
            {
                if (_typeOfPipe != value)
                {
                    _typeOfPipe = value;
                    OnPropertyChanged(nameof(TypeOfPipe));
                }
            }
        }

        private string _diaOfPipe;
        public string DiaOfPipe
        {
            get => _diaOfPipe;
            set
            {
                if (_diaOfPipe != value)
                {
                    _diaOfPipe = value;
                    OnPropertyChanged(nameof(DiaOfPipe));
                }
            }
        }


        private string _uom;
        public string Uom
        {
            get => _uom;
            set
            {
                if (_uom != value)
                {
                    _uom = value;
                    OnPropertyChanged(nameof(Uom));
                }
            }
        }

        private string _designQuantity;
        public string DesignQuantity
        {
            get => _designQuantity;
            set
            {
                if (_designQuantity != value)
                {
                    _designQuantity = value;
                    OnPropertyChanged(nameof(DesignQuantity));
                }
            }
        }

        private string _totalQuantity;
        public string TotalQuantity
        {
            get => _totalQuantity;
            set
            {
                if (_totalQuantity != value)
                {
                    _totalQuantity = value;
                    OnPropertyChanged(nameof(TotalQuantity));
                }
            }
        }
        private void UpdateLabelsBasedOnBoqReference(string boqReference)
        {
            ActivityIndicator a = new ActivityIndicator();
            a.IsRunning = true;
             Task.Delay(2000); // 
            a.IsRunning = false;

           
            TypeOfPipe = "DI K-9";
            DiaOfPipe = "25mm";
            Uom = "Meter";
        DesignQuantity= "2000";
            TotalQuantity = "1200";
            // Update other properties as needed
        }


        private async Task<ObservableCollection<BoQHead>> GetBoQHeadsFromWebApi()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var userId = 123; // Replace with the actual user ID
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetBoQHeads/{userId}";
                    var response = await client.GetStringAsync(apiUrl);
                    var boqHeads = JsonConvert.DeserializeObject<ObservableCollection<BoQHead>>(response);

                    return boqHeads;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<BoQHead>();
            }
        }


        private async Task<bool> LogicFrBOQref()
        {
            // Simulate login logic or call your actual login API
            // Replace this with your actual login implementation
            await Task.Delay(1000); // Simulating login for 2 seconds
            return true; // For demo purposes; replace with actual success/failure check
        }

        private async Task<ObservableCollection<Village>> GetVillagesFromWebApi()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var userId = 123; // Replace with the actual user ID
                    var locationId = 1; // Replace with the actual location ID
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetVillages/{userId}/{locationId}";
                    var response = await client.GetStringAsync(apiUrl);
                    var villages = JsonConvert.DeserializeObject<ObservableCollection<Village>>(response);

                    return villages;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Village>();
            }
        }


        private ObservableCollection<Location> _locations;
        public ObservableCollection<Location> Locations
        {
            get { return _locations; }
            set
            {
                if (_locations != value)
                {
                    _locations = value;
                    OnPropertyChanged(nameof(Locations));
                }
            }
        }

        private ObservableCollection<Village> _villages;
        public ObservableCollection<Village> Villages
        {
            get { return _villages; }
            set
            {
                if (_villages != value)
                {
                    _villages = value;
                    OnPropertyChanged(nameof(Villages));
                }
            }
        }

        private ObservableCollection<BoQHead> _boqHeads;
        public ObservableCollection<BoQHead> BoQHeads
        {
            get { return _boqHeads; }
            set
            {
                if (_boqHeads != value)
                {
                    _boqHeads = value;
                    OnPropertyChanged(nameof(BoQHeads));
                }
            }
        }



        private async Task<ObservableCollection<Location>> GetLocationsFromWebApi()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var userId = 123; // Replace with the actual user ID
                    var componentId = 1; // Replace with the actual component ID
                    var blockId = 1; // Replace with the actual block ID
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetLocations/{userId}/{componentId}/{blockId}";
                    var response = await client.GetStringAsync(apiUrl);
                    var locations = JsonConvert.DeserializeObject<ObservableCollection<Location>>(response);

                    return locations;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Location>();
            }
        }

        private async Task<ObservableCollection<Component>> GetComponentsFromWebApi()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var userId = "sanjay.codescreators"; // Replace with the actual user ID
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetComponents/{userId}";
                    var response = await client.GetStringAsync(apiUrl);
                    var components = JsonConvert.DeserializeObject<ObservableCollection<Component>>(response);

                    return components;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Component>();
            }
        }

        private async Task<ObservableCollection<Project>> GetProjectsFromWebApi()
        {
            try
            {
                // Use HttpClient to fetch data from the API
                using (var client = new HttpClient())
                {
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetJobs";
                    var response = await client.GetStringAsync(apiUrl);
                    var projects = JsonConvert.DeserializeObject<ObservableCollection<Project>>(response);

                    return projects;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Project>();
            }
        }

        private async Task<ObservableCollection<Block>> GetBlocksFromWebApi()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var apiUrl = $"{strAPIUrl}/api/Block/GetBlocks"; // Replace with your actual API endpoint URL
                    var response = await client.GetStringAsync(apiUrl);
                    var blocks = JsonConvert.DeserializeObject<ObservableCollection<Block>>(response);

                    return blocks;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Block>();
            }
        }


        private Project _selectedProject;
        public Project SelectedProject
        {
            get { return _selectedProject; }
            set
            {
                if (_selectedProject != value)
                {
                    _selectedProject = value;
                    OnPropertyChanged(nameof(SelectedProject));

                    // Load blocks when a project is selected
                    LoadBlocksCommand.Execute(null);
                }
            }
        }

        private Command loadBlocksCommand;
        public Command LoadBlocksCommand => loadBlocksCommand ?? (loadBlocksCommand = new Command(async () => await ExecuteLoadBlocksCommand()));

        private async Task ExecuteLoadBlocksCommand()
        {
            // Check if a project is selected
            if (SelectedProject != null)
            {
                // Assuming you have a method named GetBlocksForProjectFromWebApi to get blocks for the selected project
                Blocks = await GetBlocksForProjectFromWebApi(SelectedProject.ProjectID);
            }
        }

        private async Task<ObservableCollection<Block>> GetBlocksForProjectFromWebApi(int projectId)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var apiUrl = $"{strAPIUrl}/api/GetMaterialsDetails/GetBlocksBasedOnProject?projectId={projectId}";
                    var response = await client.GetStringAsync(apiUrl);
                    var blocks = JsonConvert.DeserializeObject<ObservableCollection<Block>>(response);

                    return blocks;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                return new ObservableCollection<Block>();
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private Command saveCommand;
        public Command SaveCommand => saveCommand ?? (saveCommand = new Command(OnSave));

        private Command submitCommand;
        public Command SubmitCommand => submitCommand ?? (submitCommand = new Command(OnSubmit));

        private void OnSave()
        {
            // Implement the logic for the Save button click
        }

        private void OnSubmit()
        {
            // Implement the logic for the Submit button click
        }

        private void OnDateTapped(object sender, EventArgs e)
        {
            // Handle the tap event here
            // You can show/hide the DatePicker or handle date selection as needed
        }

        public class BoQHead
        {
            public int Id { get; set; }
            public string BoQHeadName { get; set; }
            // Add more properties as needed
        }


        public class Project
        {
            public int ProjectID { get; set; }
            public string ProjectName { get; set; }
            public string ProjectShortName { get; set; }
        }

        public class Block
        {
            public int Id { get; set; }
            public string BlockName { get; set; }
        }

        public class Village
        {
            public int Id { get; set; }
            public string VillageName { get; set; }
            // Add more properties as needed
        }


        public class Location
        {
            public int Id { get; set; }
            public string LocationName { get; set; }
            // Add more properties as needed
        }

    }
}
